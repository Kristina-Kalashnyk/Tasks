/*Задача №15: Запросіть користувача ввести якусь фразу. Відобразіть кожне слово у
вигляді списку ul li. Також відобразіть перше слово UPPERCASE, а останні 2
з маленької. Знайдіть усі літери "а" їх кількість виведіть у alert вікно. Після
закриття alert - реалізувати скрипт, який через 5 хвилин бездіяльності
користувача (нічого не натискається, нічого не виділяється, не рухається
прогрес-бар) висвітлює повідомлення "Ви ще тут?" Якщо так, користувач
залишається на сторінці, якщо ні сторінка закривається*/
let inactivityTime = () => {
    let time;

   document.addEventListener('mousemove', resetTimer);
   document.addEventListener('keypress', resetTimer);
  
    function resetTimer() {
      clearTimeout(time);
      time = setTimeout(fn, 5000)
    }
    
    function fn() {
       if (!confirm('Ви ще тут?')) 
       window.close();
    }
  };
  
  document.addEventListener('DOMContentLoaded', () => {
    inactivityTime();
  });

function sentence() {
    let input = document.getElementById("sentence").value;
    let arr = input.split(' ');
    let count = 0;
   
    //// = input.toLowerCase(); 
    arr.splice(0,1,arr[0].toUpperCase());
    arr.splice(-1,1,arr[arr.length-1].toLowerCase());
    arr.splice(-2,1,arr[arr.length-2].toLowerCase());

    let html = '<ul>';
    arr.forEach(function(item, i, arr) {
          html += '<li>'+item+'</li>';
    });
          html += '</ul>'

    input = input.toLowerCase();      
    count = input.split("a").length - 1;
    document.write(html);
    alert (`Кількість літер А: ${count}`);
   
}
 sentence();




