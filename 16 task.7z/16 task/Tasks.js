//Задача №1: Знайти різницю між найбільшим і найменшим елементом масива; якщо масив пустий або має один елемент - повернути 0.
let myArray = [1,5,-8,11,22,6];
let emptyArray = [];
let oneElementArray = [5];

function arr(list) {
    if (list.length <= 1) return (console.log(0));
        else {
        let min = Math.min(...list);    
        let max = Math.max(...list);
                return console.log (max-min);
    }
  }

  arr(myArray);

//Задача №2: Написати функцію, яка приймає рядок і число. Поверрнути у вигляді масиву тільки ті слова, довжина яких перевищує число.
let names = "Krystyna, Alina, Alex, Yan, Jenia";

function words(str, num) {
    let arr = str.split(', ');
    let newArray = arr.filter(word => word.length > num);
    return console.log (newArray);
    /*
    for (let i = 0; i < arr.length; i++) {
        if (arr[i].length > num) {
            newArray.push(arr[i]);
        }
    }
    return console.log (newArray);*/
}
words(names, 4);

//Задача №3: Написати функцію, яка повертає true, якщо перший переданий аргумент (рядок) закінчується другим аргументом (також рядком).
let solution = (str1, str2) => console.log(str1.endsWith(str2));

solution('abc', 'bc');

//Задача №4: Написати функцію, яка отримує масив цілих чисел і повертає масив середніх значень кожного цілого числа та його послідовника, якщо він є.
let numbers = [1, 3, 5, 1, -10, -5];

function averages(arr) {
    let newArray = [];

    for (let i = 0; i < arr.length-1; i++) {
            arr[i]+arr[i+1];
            newArray.push((arr[i]+arr[i+1])/2); 
    }
    return console.log (newArray);
}
   
averages(numbers);

//Задача №5: Створити функцію, яка приймає рядок і повертає кількість голосних, які у ній.
//Створити функцію, яка видаляє літери "a", "b" і "c" з цього рядка і поверне змінену версію. Якщо цей рядок не містить "a", "b" або "c", повернути null.
function countVowels(str) {
    let vowels ='aeiou';
    let result = 0;
    let word = str.toLowerCase();

    for (let i = 0; i < word.length; i++) {
        if (vowels.indexOf(word[i]) !== -1) {
            result += 1;
        }
    }
    return console.log(result);
}

function removeABC(str) { //????????????????????????????????????????
    let letters = 'abc';
    let result = null;
    let sentence = str.toLowerCase();
    
    for (let i = 0; i < sentence.length; i++) {
        if (letters.indexOf(sentence[i]) !== -1) {
            result = sentence.replace(/[abc]/g, '');
        } 
    }
    return console.log(result);
}
 
countVowels("Celebration");
removeABC("This might be a bit hard");
removeABC("hello world!");

//Задача №6: Написати JavaScript для пошуку унікальних елементів з двох масивів. ?????????????
let difference = ((arr1, arr2) => [...new Set([...arr1, ...arr2])]);

console.log(difference([1, 2, 3], [100, 2, 1, 10]));

//Задача №7: Написати функцію, щоб отримати копію об'єкта, де ключі стали значеннями, а значення ключами.
const myObj = {
    red: "#FF0000", 
    green: "#00FF00", 
    white: "#FFFFFF"
}
const result = {};

/*Object.keys(obj) – возвращает массив ключей.
Object.values(obj) – возвращает массив значений.
Object.entries(obj) – возвращает массив пар [ключ, значение].*/

Object.entries(myObj).forEach(([key, value]) => {
  result[value] = key
});

console.log(result);

//Задача №8: Повернути різницю між загальною вартістю цих речей та межею політики.
let myObject ={ 
    skate: 10, 
    painting: 20 
};
let sum;

function calculateDifference(obj, num) {
    let result = 0;
    let sum = 0;

    for (let item of Object.values(obj)) {
      sum += item; 
    }

    if (sum > num && Object.keys(obj).length !== 0) {
        return console.log(sum - num);
    }
    else return console.log('Об`єкт завжди повинен містити елементи, сума предметів завжди повинна бути більшою за страховку.');
      
}

calculateDifference(myObject,150);

//Задача №10: Дано рядок, що містить повне ім'я файлу. Виділити із цього рядка ім'я файлу без розширення.???????

let currPathName = "c:\\WebServers\\home\\testsite\\www\\myfile.txt";
let currPathName2 = "c:/WebServers/home/testsite/www/myfile.txt";

function getSubstr(str, char, pos) {
    if(pos=='before') 
    return str.slice(0, str.indexOf(char));
 };

let newPathName = getSubstr(currPathName2, '.','before');

function path(pathname) {
    if (pathname.includes('\\')) {
        let name = pathname.split("\\").pop();
        return console.log(name); 
    } else if (pathname.includes('/')) {
        let name = pathname.split("/").pop();
        return console.log(name); 
    }
}

path(newPathName);

//Задача №11: Дано два рядки. Чи можна перший рядок отримати з циклічним зрушенням другого?

let str1, str2;

function shift(string1, string2) {
    let count = 0;
    if (string1.length >= string2.length) {
        let firstArr = string1.split('');
        let secondArr = string2.split('');
        count = secondArr.length;
       
        for(i = 0; i < count; i++) {
            firstArr.unshift(firstArr.pop());
        } 

        return console.log(`Перший рядок можна отримати з циклічним зрушенням другого: ${firstArr.join('')}`);

    } else {
        return console.log ('Перший рядок не можна отримати з циклічним зрушенням другого.');
    }
}

shift('Kristina','Ali');

//Задача №12: З елементів масиву a, що складається з 2n елементів, отримати масиви b і c наступним чином: вибрати в масиві a два
// найбільш близькі за значенням елемента, менший з них помістити в масив b, а більший - масив c. Виключити з розгляду в масиві 
//a ці елементи і продовжити вибір з елементів, що залишилися.---------------------------
let a = [3, 1, 77, 5, 6, 88, -5, 9];
let b = [];
let c = [];

function shareArr(arr) {
    if (arr.length % 2 !== 0 || arr.length < 2) 
        return console.log('Параметри масива невірні згідно з умовою.')
    else {
        arr.sort((a,b) => a - b);
        while (arr.length > 0) {
            let index = 0;
            let nextPosition = 0;
            let difference = Math.abs(arr[0] - arr[1]);
        for (let i = 0; i < arr.length - 1; i++) {
            if (Math.abs(arr[i] - arr[i+1]) < difference)
                    {
                        difference = Math.abs(arr[i] - arr[i+1]);
                        index = i;
                        
                    }
                    if (b.length !== 0) {
                        b.unshift(arr[index]);
                        c.unshift(arr[index + 1]);
                        arr.pop();
                        
                    } else {
                        b[nextPosition] = arr[index];
                        c[nextPosition] = arr[index + 1];
                        nextPosition++;
                        arr.pop();
                    }  
                    
        }
        return console.log(`Array b = ${b}; array c = ${c}`);
        /*return console.log(arr);*/
    }
} 
}

shareArr(a);


//Задача №13
//Задача №14

function js(text){
    var i,
            l=text.length,
            char,
            last,
            stack=[];

    for(i=0; i<l; i++){
        char=text[i];

        if(char=="{" || char=="("){
            stack.push(char);
        }else if(char=="}" || char==")"){
            if(stack.length>0){
                last=stack[stack.length-1];
                if ((char == '}' && last == "{") || (char == ')' && last == '(')) {
                    stack.pop();
                }
            }
        }
    }
    return stack.length==0;
}
js('())(');

//Задача №15
//Задача №16: Створити пароль для користувача. Вимоги: довжина від 6 до 20  символів повинен бути рівно один символ підкреслення,
// хоча б дві великі літери, не більше 5 цифр, будь-які дві цифри поспіль неприпустимі.


//Задача №17: В заданому масиві найменший елемент помістити на перше місце, найменший з тих, що залишилися - на останнє місце,
// наступний - передостаннє і так далі - до середини масиву.

let myArr = [5,3,6,4,2,7,1];
let sortedArr = myArr.sort((a,b) => a-b);
let resultArr = [];

function sorting(arr) {
    for (let i = 0; i < arr.length; i++) {
        resultArr[i] = arr[i];
        resultArr[arr.length] = arr[i+1];
        resultArr[arr.length-1] = arr[i+2];
        resultArr[arr.length-2] = arr[i+3];
        resultArr[arr.length-3] = arr[i+4];
        
        /*resultArr[arr.length] = arr[i]
        resultArr[arr.length] = arr[i];;*/
        break;
    }
    return console.log(resultArr);
}

sorting(sortedArr);
