//Задача №14: Перевірити, чи дотримується в заданому тексті баланс круглих дужок,що відкривають і закривають, 
//тобто можна встановити взаємно однозначну відповідність відкривають і закривають дужок, причому
//відкриває дужка завжди передує відповідної закриває. Якщо баланс дотримується вивести цей текст на html–сторінку
//і забороніть користувачу копіювати цей текст та перегляд коду сторінки.
function brackets(text){
    let  char,
            last,
            stack=[];

    for(let i=0; i<text.length; i++){
        char=text[i];

        if( char=="("){
            stack.push(char);
        }else if(char==")"){
            if(stack.length>0){
                last=stack[stack.length-1];
                if ((char == ')' && last == '(')) {
                    stack.pop();
                }
            }
        }
    }
    if (stack.length==0) 
      document.write('Баланс дужок дотримується');
      else 
      document.write('Баланс дужок не дотримується');
     
      
}
  document.ondragstart = noselect;
  document.onselectstart = noselect;
  document.oncontextmenu = noselect;

  function noselect() {
        return false;
    }

brackets('((((())');
