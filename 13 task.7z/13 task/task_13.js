/*Дано рядок, що складається зі слів, розділених пробілами. Сформувати
новий рядок з такими властивостями: а) усі слова у нижньому регістрі, крім
першої літери першого слова; б) усі посилання у словах замінюються на
"[посилання заборонено]"; в) всі email замінюються на "[контакти
заборонені]"; г) усі слова довжини понад 3 символи, що містять лише цифри,
видаляються.
Якщо кількість символів в отриманому рядку буде більшої ніж
кількість символів у вихідному, то запустити функцію, що буде кожні 5
секунд в alert буде питати, чи потрібна нам допомога.
 */
let myString= 'мій новий пароль 17 до електроної адреси kristina@gmail.com та акаунту Linkedin https://www.linkedin.com/in/krystyna-kalashnyk а старий пароль був 4568';

withoutEmail = myString.replace(/([^.@\s]+)(\.[^.@\s]+)*@([^.@\s]+\.)+([^.@\s]+)/,"[контакти заборонені]");
withoutLink = withoutEmail.replace(/(?:https?|ftp):\/\/[\n\S]+/g,"[посилання заборонено]");
result = withoutLink.replace(/[0-9]{3,}/g,"");
result.toLowerCase();

function capitalizeFirstLetter(string) {
    return console.log(string.charAt(0).toUpperCase() + string.slice(1));
}
capitalizeFirstLetter(result);

let question = () => alert('Чи потрібна Вам допомога?');
arr = myString.split(' ');
newArr = result.split(' ');

if ((newArr.length) > (arr.length)) {
    setInterval(question, 5000);
}