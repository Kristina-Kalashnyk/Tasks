
function checkForm()
{
    let myInput = document.getElementById("psw").value;
    if((myInput.length < 6) ||(myInput.length > 20)) 
    alert('Довжина пароля має бути від 6 до 20 символів!');

    let smbl = /[^-&]{1}/g;
    if (myInput.match(smbl))
    alert('Пароль має містити один символ _');

        
}

