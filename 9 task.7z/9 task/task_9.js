//Задача №9: Написати функцію, яка приймає три виміри цегли: висоту (a), ширину (b) і глибину (c) і повертає істину, 
//якщо ця цегла може поміститися в отвір з шириною (w) та висотою (h). Виміри вводить користувач через форму.

function count() {          
  let a = document.getElementById("width").value;
  let b = document.getElementById("length").value;
  let c = document.getElementById("height").value;
  let h = document.getElementById("slot-width").value;
  let w = document.getElementById("slot-length").value;
  
  function doesBrickFit(a, b, c, h, w) {
    
    if (((h >= c) && (w >= b)) ||
    ((h >= b) && (w >= c)) ||
    ((h >= c) && (w >= a)) ||
    ((h >= a) && (w >= d)) ||
    ((h >= b) && (w >= a)) ||
    ((h >= a) && (w >= b))) {
      alert('Цеглина поміститься в отвір');
      return console.log(true);
    }
    else {
      alert('Цеглина не поміститься в отвір');
      return console.log(false);
    }           
   }

   doesBrickFit(a,b,c,h,w);
}


